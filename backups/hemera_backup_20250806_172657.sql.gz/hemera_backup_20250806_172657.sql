--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13
-- Dumped by pg_dump version 15.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP POLICY IF EXISTS "Users can view questoes of active simulados" ON public.questoes;
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can view own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can view own notifications" ON public.assignment_notifications;
DROP POLICY IF EXISTS "Users can view own enrollments" ON public.course_enrollments;
DROP POLICY IF EXISTS "Users can view own certificates" ON public.course_certificates;
DROP POLICY IF EXISTS "Users can view own assignments" ON public.course_assignments;
DROP POLICY IF EXISTS "Users can view opcoes of active simulados" ON public.opcoes_resposta;
DROP POLICY IF EXISTS "Users can view lessons of enrolled courses" ON public.video_lessons;
DROP POLICY IF EXISTS "Users can view active video courses assigned to them" ON public.video_courses;
DROP POLICY IF EXISTS "Users can view active simulados" ON public.simulados;
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Users can update own notifications" ON public.notifications;
DROP POLICY IF EXISTS "Users can update own notifications" ON public.assignment_notifications;
DROP POLICY IF EXISTS "Users can update own enrollment progress" ON public.course_enrollments;
DROP POLICY IF EXISTS "Users can manage own notification preferences" ON public.notification_preferences;
DROP POLICY IF EXISTS "Users can manage own lesson progress" ON public.lesson_progress;
DROP POLICY IF EXISTS "Users can manage own attempts" ON public.simulado_attempts;
DROP POLICY IF EXISTS "Users can manage own answers" ON public.user_answers;
DROP POLICY IF EXISTS "System can manage email queue" ON public.email_queue;
DROP POLICY IF EXISTS "System can create notifications" ON public.notifications;
DROP POLICY IF EXISTS "System can create notifications" ON public.assignment_notifications;
DROP POLICY IF EXISTS "System can create certificates" ON public.course_certificates;
ALTER TABLE IF EXISTS ONLY public.video_lessons DROP CONSTRAINT IF EXISTS video_lessons_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.video_courses DROP CONSTRAINT IF EXISTS video_courses_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.user_answers DROP CONSTRAINT IF EXISTS user_answers_questao_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_answers DROP CONSTRAINT IF EXISTS user_answers_opcao_resposta_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_answers DROP CONSTRAINT IF EXISTS user_answers_attempt_id_fkey;
ALTER TABLE IF EXISTS ONLY public.template_courses DROP CONSTRAINT IF EXISTS template_courses_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.simulados DROP CONSTRAINT IF EXISTS simulados_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.simulado_attempts DROP CONSTRAINT IF EXISTS simulado_attempts_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.simulado_attempts DROP CONSTRAINT IF EXISTS simulado_attempts_simulado_id_fkey;
ALTER TABLE IF EXISTS ONLY public.questoes DROP CONSTRAINT IF EXISTS questoes_simulado_id_fkey;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.opcoes_resposta DROP CONSTRAINT IF EXISTS opcoes_resposta_questao_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lesson_progress DROP CONSTRAINT IF EXISTS lesson_progress_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lesson_progress DROP CONSTRAINT IF EXISTS lesson_progress_lesson_id_fkey;
ALTER TABLE IF EXISTS ONLY public.lesson_progress DROP CONSTRAINT IF EXISTS lesson_progress_enrollment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_templates DROP CONSTRAINT IF EXISTS email_templates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.email_queue DROP CONSTRAINT IF EXISTS email_queue_template_id_fkey;
ALTER TABLE IF EXISTS ONLY public.email_logs DROP CONSTRAINT IF EXISTS email_logs_queue_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS course_enrollments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS course_enrollments_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS course_enrollments_assigned_by_fkey;
ALTER TABLE IF EXISTS ONLY public.course_certificates DROP CONSTRAINT IF EXISTS course_certificates_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_certificates DROP CONSTRAINT IF EXISTS course_certificates_enrollment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_certificates DROP CONSTRAINT IF EXISTS course_certificates_course_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_assignments DROP CONSTRAINT IF EXISTS course_assignments_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.course_assignments DROP CONSTRAINT IF EXISTS course_assignments_assigned_by_fkey;
ALTER TABLE IF EXISTS ONLY public.assignment_templates DROP CONSTRAINT IF EXISTS assignment_templates_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.assignment_notifications DROP CONSTRAINT IF EXISTS assignment_notifications_assignment_id_fkey;
DROP TRIGGER IF EXISTS update_video_lessons_updated_at ON public.video_lessons;
DROP TRIGGER IF EXISTS update_video_courses_updated_at ON public.video_courses;
DROP TRIGGER IF EXISTS update_smtp_config_updated_at ON public.smtp_config;
DROP TRIGGER IF EXISTS update_simulados_updated_at ON public.simulados;
DROP TRIGGER IF EXISTS update_questoes_updated_at ON public.questoes;
DROP TRIGGER IF EXISTS update_profiles_updated_at ON public.profiles;
DROP TRIGGER IF EXISTS update_notification_preferences_updated_at ON public.notification_preferences;
DROP TRIGGER IF EXISTS update_lesson_progress_updated_at ON public.lesson_progress;
DROP TRIGGER IF EXISTS update_email_templates_updated_at ON public.email_templates;
DROP TRIGGER IF EXISTS update_email_queue_updated_at ON public.email_queue;
DROP TRIGGER IF EXISTS update_course_assignments_updated_at ON public.course_assignments;
DROP TRIGGER IF EXISTS update_assignment_templates_updated_at ON public.assignment_templates;
DROP TRIGGER IF EXISTS update_assignment_status_trigger ON public.course_enrollments;
DROP TRIGGER IF EXISTS update_users_updated_at ON auth.users;
DROP INDEX IF EXISTS public.idx_video_lessons_order;
DROP INDEX IF EXISTS public.idx_video_lessons_course_id;
DROP INDEX IF EXISTS public.idx_template_courses_template_id;
DROP INDEX IF EXISTS public.idx_template_courses_content;
DROP INDEX IF EXISTS public.idx_profiles_user_id;
DROP INDEX IF EXISTS public.idx_notifications_user_id;
DROP INDEX IF EXISTS public.idx_notifications_unread;
DROP INDEX IF EXISTS public.idx_notifications_type;
DROP INDEX IF EXISTS public.idx_lesson_progress_user_lesson;
DROP INDEX IF EXISTS public.idx_lesson_progress_enrollment;
DROP INDEX IF EXISTS public.idx_email_queue_status;
DROP INDEX IF EXISTS public.idx_email_queue_scheduled;
DROP INDEX IF EXISTS public.idx_email_queue_priority;
DROP INDEX IF EXISTS public.idx_email_logs_status;
DROP INDEX IF EXISTS public.idx_email_logs_email;
DROP INDEX IF EXISTS public.idx_course_enrollments_user_id;
DROP INDEX IF EXISTS public.idx_course_enrollments_course_id;
DROP INDEX IF EXISTS public.idx_course_assignments_user_id;
DROP INDEX IF EXISTS public.idx_course_assignments_status;
DROP INDEX IF EXISTS public.idx_course_assignments_due_date;
DROP INDEX IF EXISTS public.idx_course_assignments_content;
DROP INDEX IF EXISTS public.idx_course_assignments_assigned_by;
DROP INDEX IF EXISTS public.idx_assignment_templates_job_title;
DROP INDEX IF EXISTS public.idx_assignment_templates_department;
DROP INDEX IF EXISTS public.idx_assignment_notifications_assignment_id;
DROP INDEX IF EXISTS auth.idx_users_email;
ALTER TABLE IF EXISTS ONLY public.video_lessons DROP CONSTRAINT IF EXISTS video_lessons_pkey;
ALTER TABLE IF EXISTS ONLY public.video_courses DROP CONSTRAINT IF EXISTS video_courses_pkey;
ALTER TABLE IF EXISTS ONLY public.user_answers DROP CONSTRAINT IF EXISTS user_answers_pkey;
ALTER TABLE IF EXISTS ONLY public.template_courses DROP CONSTRAINT IF EXISTS template_courses_template_id_content_type_content_id_key;
ALTER TABLE IF EXISTS ONLY public.template_courses DROP CONSTRAINT IF EXISTS template_courses_pkey;
ALTER TABLE IF EXISTS ONLY public.smtp_config DROP CONSTRAINT IF EXISTS smtp_config_pkey;
ALTER TABLE IF EXISTS ONLY public.simulados DROP CONSTRAINT IF EXISTS simulados_pkey;
ALTER TABLE IF EXISTS ONLY public.simulado_attempts DROP CONSTRAINT IF EXISTS simulado_attempts_pkey;
ALTER TABLE IF EXISTS ONLY public.questoes DROP CONSTRAINT IF EXISTS questoes_pkey;
ALTER TABLE IF EXISTS ONLY public.profiles DROP CONSTRAINT IF EXISTS profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.opcoes_resposta DROP CONSTRAINT IF EXISTS opcoes_resposta_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_user_id_key;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.lesson_progress DROP CONSTRAINT IF EXISTS lesson_progress_user_id_lesson_id_enrollment_id_key;
ALTER TABLE IF EXISTS ONLY public.lesson_progress DROP CONSTRAINT IF EXISTS lesson_progress_pkey;
ALTER TABLE IF EXISTS ONLY public.email_templates DROP CONSTRAINT IF EXISTS email_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.email_queue DROP CONSTRAINT IF EXISTS email_queue_pkey;
ALTER TABLE IF EXISTS ONLY public.email_logs DROP CONSTRAINT IF EXISTS email_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS course_enrollments_user_id_course_id_key;
ALTER TABLE IF EXISTS ONLY public.course_enrollments DROP CONSTRAINT IF EXISTS course_enrollments_pkey;
ALTER TABLE IF EXISTS ONLY public.course_certificates DROP CONSTRAINT IF EXISTS course_certificates_user_id_course_id_key;
ALTER TABLE IF EXISTS ONLY public.course_certificates DROP CONSTRAINT IF EXISTS course_certificates_pkey;
ALTER TABLE IF EXISTS ONLY public.course_assignments DROP CONSTRAINT IF EXISTS course_assignments_user_id_content_type_content_id_key;
ALTER TABLE IF EXISTS ONLY public.course_assignments DROP CONSTRAINT IF EXISTS course_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.assignment_templates DROP CONSTRAINT IF EXISTS assignment_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.assignment_notifications DROP CONSTRAINT IF EXISTS assignment_notifications_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY auth.users DROP CONSTRAINT IF EXISTS users_email_key;
DROP TABLE IF EXISTS public.video_lessons;
DROP TABLE IF EXISTS public.video_courses;
DROP TABLE IF EXISTS public.user_answers;
DROP TABLE IF EXISTS public.template_courses;
DROP TABLE IF EXISTS public.smtp_config;
DROP TABLE IF EXISTS public.simulados;
DROP TABLE IF EXISTS public.simulado_attempts;
DROP TABLE IF EXISTS public.questoes;
DROP TABLE IF EXISTS public.profiles;
DROP TABLE IF EXISTS public.opcoes_resposta;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.lesson_progress;
DROP TABLE IF EXISTS public.email_templates;
DROP TABLE IF EXISTS public.email_queue;
DROP TABLE IF EXISTS public.email_logs;
DROP TABLE IF EXISTS public.course_enrollments;
DROP TABLE IF EXISTS public.course_certificates;
DROP TABLE IF EXISTS public.course_assignments;
DROP TABLE IF EXISTS public.assignment_templates;
DROP TABLE IF EXISTS public.assignment_notifications;
DROP TABLE IF EXISTS auth.users;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_assignment_status();
DROP FUNCTION IF EXISTS public.mark_overdue_assignments();
DROP FUNCTION IF EXISTS public.mark_notification_read(p_notification_id uuid);
DROP FUNCTION IF EXISTS public.is_admin_user(user_uuid uuid);
DROP FUNCTION IF EXISTS public.get_unread_notification_count(p_user_id uuid);
DROP FUNCTION IF EXISTS public.create_notification(p_user_id uuid, p_title character varying, p_message text, p_type character varying, p_category character varying, p_data jsonb, p_expires_at timestamp with time zone);
DROP FUNCTION IF EXISTS public.apply_template_to_user(p_template_id uuid, p_user_id uuid, p_assigned_by uuid);
DROP FUNCTION IF EXISTS auth.update_updated_at_column();
DROP FUNCTION IF EXISTS auth.uid();
DROP FUNCTION IF EXISTS auth.set_user_id(user_id uuid);
DROP TYPE IF EXISTS public.question_type;
DROP TYPE IF EXISTS public.difficulty_level;
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS pgcrypto;
DROP SCHEMA IF EXISTS auth;
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: hemera_user
--

CREATE SCHEMA auth;


ALTER SCHEMA auth OWNER TO hemera_user;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: difficulty_level; Type: TYPE; Schema: public; Owner: hemera_user
--

CREATE TYPE public.difficulty_level AS ENUM (
    'facil',
    'medio',
    'dificil'
);


ALTER TYPE public.difficulty_level OWNER TO hemera_user;

--
-- Name: question_type; Type: TYPE; Schema: public; Owner: hemera_user
--

CREATE TYPE public.question_type AS ENUM (
    'multiple_choice',
    'single_answer'
);


ALTER TYPE public.question_type OWNER TO hemera_user;

--
-- Name: set_user_id(uuid); Type: FUNCTION; Schema: auth; Owner: hemera_user
--

CREATE FUNCTION auth.set_user_id(user_id uuid) RETURNS void
    LANGUAGE sql
    AS $$
  SELECT set_config('app.current_user_id', user_id::TEXT, true);
$$;


ALTER FUNCTION auth.set_user_id(user_id uuid) OWNER TO hemera_user;

--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: hemera_user
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  SELECT COALESCE(
    current_setting('app.current_user_id', true)::UUID,
    NULL
  );
$$;


ALTER FUNCTION auth.uid() OWNER TO hemera_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: auth; Owner: hemera_user
--

CREATE FUNCTION auth.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION auth.update_updated_at_column() OWNER TO hemera_user;

--
-- Name: apply_template_to_user(uuid, uuid, uuid); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.apply_template_to_user(p_template_id uuid, p_user_id uuid, p_assigned_by uuid) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  template_course RECORD;
  assignments_created INTEGER := 0;
  due_date_calc TIMESTAMP WITH TIME ZONE;
BEGIN
  -- Check if user applying is admin
  IF NOT is_admin_user(p_assigned_by) THEN
    RAISE EXCEPTION 'Unauthorized: Only admins can apply templates';
  END IF;
  
  -- Check if template exists and is active
  IF NOT EXISTS (
    SELECT 1 FROM public.assignment_templates 
    WHERE id = p_template_id AND is_active = true
  ) THEN
    RAISE EXCEPTION 'Template not found or inactive';
  END IF;
  
  -- Apply each course from template
  FOR template_course IN 
    SELECT tc.*
    FROM public.template_courses tc
    WHERE tc.template_id = p_template_id
  LOOP
    -- Calculate due date
    due_date_calc := CASE 
      WHEN template_course.default_due_days > 0 
      THEN NOW() + (template_course.default_due_days || ' days')::INTERVAL
      ELSE NULL
    END;
    
    -- Create assignment if not exists
    INSERT INTO public.course_assignments (
      user_id,
      content_type,
      content_id,
      assigned_by,
      due_date,
      priority,
      notes
    ) VALUES (
      p_user_id,
      template_course.content_type,
      template_course.content_id,
      p_assigned_by,
      due_date_calc,
      template_course.priority,
      'Assigned automatically via template'
    )
    ON CONFLICT (user_id, content_type, content_id) DO NOTHING;
    
    -- Count if new assignment was created
    IF FOUND THEN
      assignments_created := assignments_created + 1;
      
      -- Create notification
      INSERT INTO public.assignment_notifications (assignment_id, notification_type)
      SELECT id, 'assignment_created'
      FROM public.course_assignments
      WHERE user_id = p_user_id 
      AND content_type = template_course.content_type
      AND content_id = template_course.content_id;
    END IF;
  END LOOP;
  
  RETURN assignments_created;
END;
$$;


ALTER FUNCTION public.apply_template_to_user(p_template_id uuid, p_user_id uuid, p_assigned_by uuid) OWNER TO hemera_user;

--
-- Name: create_notification(uuid, character varying, text, character varying, character varying, jsonb, timestamp with time zone); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.create_notification(p_user_id uuid, p_title character varying, p_message text, p_type character varying DEFAULT 'info'::character varying, p_category character varying DEFAULT 'system'::character varying, p_data jsonb DEFAULT '{}'::jsonb, p_expires_at timestamp with time zone DEFAULT NULL::timestamp with time zone) RETURNS uuid
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  notification_id UUID;
BEGIN
  -- Create notification
  INSERT INTO public.notifications (
    user_id,
    title,
    message,
    type,
    category,
    data,
    expires_at
  ) VALUES (
    p_user_id,
    p_title,
    p_message,
    p_type,
    p_category,
    p_data,
    p_expires_at
  )
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$;


ALTER FUNCTION public.create_notification(p_user_id uuid, p_title character varying, p_message text, p_type character varying, p_category character varying, p_data jsonb, p_expires_at timestamp with time zone) OWNER TO hemera_user;

--
-- Name: get_unread_notification_count(uuid); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.get_unread_notification_count(p_user_id uuid DEFAULT NULL::uuid) RETURNS integer
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  target_user_id UUID;
  unread_count INTEGER;
BEGIN
  target_user_id := COALESCE(p_user_id, auth.uid());
  
  SELECT COUNT(*)::INTEGER INTO unread_count
  FROM public.notifications
  WHERE user_id = target_user_id
  AND is_read = false
  AND (expires_at IS NULL OR expires_at > NOW());
  
  RETURN unread_count;
END;
$$;


ALTER FUNCTION public.get_unread_notification_count(p_user_id uuid) OWNER TO hemera_user;

--
-- Name: is_admin_user(uuid); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.is_admin_user(user_uuid uuid) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles 
    WHERE user_id = user_uuid 
    AND (job_position ILIKE '%admin%' OR job_position ILIKE '%gerente%' OR job_position ILIKE '%diretor%')
  );
$$;


ALTER FUNCTION public.is_admin_user(user_uuid uuid) OWNER TO hemera_user;

--
-- Name: mark_notification_read(uuid); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.mark_notification_read(p_notification_id uuid) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  UPDATE public.notifications
  SET is_read = true, read_at = NOW()
  WHERE id = p_notification_id
  AND user_id = auth.uid();
  
  RETURN FOUND;
END;
$$;


ALTER FUNCTION public.mark_notification_read(p_notification_id uuid) OWNER TO hemera_user;

--
-- Name: mark_overdue_assignments(); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.mark_overdue_assignments() RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  -- Mark assignments as overdue
  UPDATE public.course_assignments 
  SET 
    status = 'overdue',
    updated_at = NOW()
  WHERE due_date < NOW()
  AND status IN ('assigned', 'in_progress');
  
  -- Create overdue notifications
  INSERT INTO public.assignment_notifications (assignment_id, notification_type)
  SELECT id, 'overdue'
  FROM public.course_assignments
  WHERE status = 'overdue'
  AND id NOT IN (
    SELECT assignment_id 
    FROM public.assignment_notifications 
    WHERE notification_type = 'overdue'
  );
END;
$$;


ALTER FUNCTION public.mark_overdue_assignments() OWNER TO hemera_user;

--
-- Name: update_assignment_status(); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.update_assignment_status() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  -- Update assignment status when course is completed
  IF NEW.progress_percentage = 100 AND OLD.progress_percentage < 100 THEN
    UPDATE public.course_assignments 
    SET 
      status = 'completed',
      completed_at = NOW(),
      updated_at = NOW()
    WHERE user_id = NEW.user_id 
    AND content_type = 'course'
    AND content_id = NEW.course_id
    AND status != 'completed';
    
    -- Create completion notification
    INSERT INTO public.assignment_notifications (assignment_id, notification_type)
    SELECT id, 'completed'
    FROM public.course_assignments
    WHERE user_id = NEW.user_id 
    AND content_type = 'course'
    AND content_id = NEW.course_id;
  
  -- Update status to in_progress when course is started
  ELSIF NEW.progress_percentage > 0 AND OLD.progress_percentage = 0 THEN
    UPDATE public.course_assignments 
    SET 
      status = 'in_progress',
      updated_at = NOW()
    WHERE user_id = NEW.user_id 
    AND content_type = 'course'
    AND content_id = NEW.course_id
    AND status = 'assigned';
  END IF;
  
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_assignment_status() OWNER TO hemera_user;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: hemera_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO hemera_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: auth; Owner: hemera_user
--

CREATE TABLE auth.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    email_confirmed boolean DEFAULT false,
    last_sign_in_at timestamp with time zone
);


ALTER TABLE auth.users OWNER TO hemera_user;

--
-- Name: assignment_notifications; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.assignment_notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    assignment_id uuid NOT NULL,
    notification_type character varying(50) NOT NULL,
    sent_at timestamp with time zone DEFAULT now(),
    email_sent boolean DEFAULT false,
    in_app_read boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT assignment_notifications_notification_type_check CHECK (((notification_type)::text = ANY ((ARRAY['assignment_created'::character varying, 'due_soon'::character varying, 'overdue'::character varying, 'completed'::character varying, 'reminder'::character varying])::text[])))
);


ALTER TABLE public.assignment_notifications OWNER TO hemera_user;

--
-- Name: assignment_templates; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.assignment_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    department character varying(100),
    job_title character varying(100),
    description text,
    is_active boolean DEFAULT true,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.assignment_templates OWNER TO hemera_user;

--
-- Name: TABLE assignment_templates; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.assignment_templates IS 'Templates for course assignments by role or department';


--
-- Name: course_assignments; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.course_assignments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    content_type character varying(10) NOT NULL,
    content_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    assigned_at timestamp with time zone DEFAULT now(),
    due_date timestamp with time zone,
    priority character varying(10) DEFAULT 'medium'::character varying,
    status character varying(20) DEFAULT 'assigned'::character varying,
    completed_at timestamp with time zone,
    notes text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT course_assignments_content_type_check CHECK (((content_type)::text = ANY ((ARRAY['course'::character varying, 'simulado'::character varying])::text[]))),
    CONSTRAINT course_assignments_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[]))),
    CONSTRAINT course_assignments_status_check CHECK (((status)::text = ANY ((ARRAY['assigned'::character varying, 'in_progress'::character varying, 'completed'::character varying, 'overdue'::character varying])::text[])))
);


ALTER TABLE public.course_assignments OWNER TO hemera_user;

--
-- Name: TABLE course_assignments; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.course_assignments IS 'Course assignments for specific users';


--
-- Name: course_certificates; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.course_certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    course_id uuid NOT NULL,
    enrollment_id uuid NOT NULL,
    certificate_url text,
    issued_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.course_certificates OWNER TO hemera_user;

--
-- Name: course_enrollments; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.course_enrollments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    course_id uuid NOT NULL,
    assigned_by uuid,
    enrolled_at timestamp with time zone DEFAULT now() NOT NULL,
    due_date timestamp with time zone,
    completed_at timestamp with time zone,
    progress_percentage integer DEFAULT 0,
    last_accessed_at timestamp with time zone
);


ALTER TABLE public.course_enrollments OWNER TO hemera_user;

--
-- Name: TABLE course_enrollments; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.course_enrollments IS 'User enrollments in courses';


--
-- Name: email_logs; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.email_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    queue_id uuid,
    to_email character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    status character varying(20) NOT NULL,
    provider character varying(50),
    provider_message_id character varying(255),
    opened_at timestamp with time zone,
    clicked_at timestamp with time zone,
    bounced_at timestamp with time zone,
    bounce_reason text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_logs OWNER TO hemera_user;

--
-- Name: email_queue; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.email_queue (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    to_email character varying(255) NOT NULL,
    to_name character varying(255),
    from_email character varying(255) NOT NULL,
    from_name character varying(255),
    subject character varying(500) NOT NULL,
    html_content text NOT NULL,
    text_content text,
    template_id uuid,
    template_variables jsonb DEFAULT '{}'::jsonb,
    priority integer DEFAULT 5,
    status character varying(20) DEFAULT 'pending'::character varying,
    attempts integer DEFAULT 0,
    max_attempts integer DEFAULT 3,
    scheduled_for timestamp with time zone DEFAULT now(),
    sent_at timestamp with time zone,
    failed_at timestamp with time zone,
    error_message text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT email_queue_status_check CHECK (((status)::text = ANY ((ARRAY['pending'::character varying, 'processing'::character varying, 'sent'::character varying, 'failed'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.email_queue OWNER TO hemera_user;

--
-- Name: TABLE email_queue; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.email_queue IS 'Email queue for asynchronous processing';


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.email_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    subject character varying(500) NOT NULL,
    template_type character varying(50) NOT NULL,
    html_content text NOT NULL,
    text_content text,
    variables jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.email_templates OWNER TO hemera_user;

--
-- Name: lesson_progress; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.lesson_progress (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    lesson_id uuid NOT NULL,
    enrollment_id uuid NOT NULL,
    watched_seconds integer DEFAULT 0,
    completed_at timestamp with time zone,
    last_position_seconds integer DEFAULT 0,
    is_completed boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.lesson_progress OWNER TO hemera_user;

--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.notification_preferences (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    email_notifications boolean DEFAULT true,
    push_notifications boolean DEFAULT true,
    assignment_notifications boolean DEFAULT true,
    certificate_notifications boolean DEFAULT true,
    reminder_notifications boolean DEFAULT true,
    marketing_notifications boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notification_preferences OWNER TO hemera_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.notifications (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(50) NOT NULL,
    category character varying(50),
    data jsonb DEFAULT '{}'::jsonb,
    is_read boolean DEFAULT false,
    read_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO hemera_user;

--
-- Name: TABLE notifications; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.notifications IS 'In-app notifications for users';


--
-- Name: opcoes_resposta; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.opcoes_resposta (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    questao_id uuid,
    option_text text NOT NULL,
    is_correct boolean DEFAULT false,
    order_number integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.opcoes_resposta OWNER TO hemera_user;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.profiles (
    user_id uuid NOT NULL,
    full_name text,
    job_position text,
    department text,
    phone text,
    avatar_url text,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.profiles OWNER TO hemera_user;

--
-- Name: TABLE profiles; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.profiles IS 'User profiles with additional information';


--
-- Name: questoes; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.questoes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    simulado_id uuid,
    question_text text NOT NULL,
    question_type public.question_type DEFAULT 'multiple_choice'::public.question_type NOT NULL,
    explanation text,
    order_number integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.questoes OWNER TO hemera_user;

--
-- Name: simulado_attempts; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.simulado_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    simulado_id uuid,
    score numeric(5,2),
    total_questions integer,
    correct_answers integer,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    status text DEFAULT 'in_progress'::text,
    CONSTRAINT simulado_attempts_status_check CHECK ((status = ANY (ARRAY['in_progress'::text, 'completed'::text, 'abandoned'::text])))
);


ALTER TABLE public.simulado_attempts OWNER TO hemera_user;

--
-- Name: simulados; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.simulados (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    duration_minutes integer DEFAULT 60 NOT NULL,
    total_questions integer DEFAULT 10 NOT NULL,
    difficulty public.difficulty_level DEFAULT 'medio'::public.difficulty_level,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.simulados OWNER TO hemera_user;

--
-- Name: smtp_config; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.smtp_config (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) DEFAULT 'default'::character varying NOT NULL,
    host character varying(255) NOT NULL,
    port integer DEFAULT 587 NOT NULL,
    username character varying(255) NOT NULL,
    password_encrypted text NOT NULL,
    use_tls boolean DEFAULT true,
    use_ssl boolean DEFAULT false,
    from_email character varying(255) NOT NULL,
    from_name character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.smtp_config OWNER TO hemera_user;

--
-- Name: template_courses; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.template_courses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    template_id uuid NOT NULL,
    content_type character varying(10) NOT NULL,
    content_id uuid NOT NULL,
    is_mandatory boolean DEFAULT true,
    default_due_days integer DEFAULT 30,
    priority character varying(10) DEFAULT 'medium'::character varying,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT template_courses_content_type_check CHECK (((content_type)::text = ANY ((ARRAY['course'::character varying, 'simulado'::character varying])::text[]))),
    CONSTRAINT template_courses_priority_check CHECK (((priority)::text = ANY ((ARRAY['low'::character varying, 'medium'::character varying, 'high'::character varying])::text[])))
);


ALTER TABLE public.template_courses OWNER TO hemera_user;

--
-- Name: user_answers; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.user_answers (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    attempt_id uuid,
    questao_id uuid,
    opcao_resposta_id uuid,
    answer_text text,
    is_correct boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.user_answers OWNER TO hemera_user;

--
-- Name: video_courses; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.video_courses (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    title text NOT NULL,
    description text,
    category text,
    thumbnail_url text,
    duration_minutes integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.video_courses OWNER TO hemera_user;

--
-- Name: TABLE video_courses; Type: COMMENT; Schema: public; Owner: hemera_user
--

COMMENT ON TABLE public.video_courses IS 'Video courses available in the system';


--
-- Name: video_lessons; Type: TABLE; Schema: public; Owner: hemera_user
--

CREATE TABLE public.video_lessons (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    course_id uuid NOT NULL,
    title text NOT NULL,
    description text,
    video_url text NOT NULL,
    video_type text DEFAULT 'youtube'::text NOT NULL,
    duration_minutes integer DEFAULT 0,
    order_number integer NOT NULL,
    is_required boolean DEFAULT true,
    min_watch_time_seconds integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.video_lessons OWNER TO hemera_user;

--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: hemera_user
--

COPY auth.users (id, email, password_hash, created_at, updated_at, email_confirmed, last_sign_in_at) FROM stdin;
00000000-0000-0000-0000-000000000001	superadmin@hcp.com	$2a$06$OIr2nf3PQxjsI.zlKkGKseG7FVHbXSVK3fHqv9KjlPghO3QT4TxpK	2025-08-04 20:47:12.823983+00	2025-08-04 20:47:12.823983+00	t	\N
00000000-0000-0000-0000-000000000002	admin@hcp.com	$2a$06$6LXhEgl.XcaMj0sn.ol.3uBVwd70thBz0jubJRwcyMjXXRKNWdTHy	2025-08-04 20:47:12.823983+00	2025-08-04 21:08:02.585173+00	f	\N
a04ea6c4-cfda-4be8-a430-81051522586f	belmirokunga@pro.com	$2b$10$hmQqv97Re5cnxeVNrtMUmeZ1lheyvVRmqZJ9DXqtMNu39gr48zuX6	2025-08-04 21:11:43.337727+00	2025-08-04 21:42:25.919226+00	t	\N
00000000-0000-0000-0000-000000000003	funcionario.teste@hcp.com	$2a$06$MRY1fr4f76waRRfxUHvfX.RDEwW.vB1SgWtTkyGQfSUCx3a9M5QtC	2025-08-04 20:47:12.823983+00	2025-08-04 21:42:58.054724+00	t	\N
\.


--
-- Data for Name: assignment_notifications; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.assignment_notifications (id, assignment_id, notification_type, sent_at, email_sent, in_app_read, created_at) FROM stdin;
\.


--
-- Data for Name: assignment_templates; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.assignment_templates (id, name, department, job_title, description, is_active, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: course_assignments; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.course_assignments (id, user_id, content_type, content_id, assigned_by, assigned_at, due_date, priority, status, completed_at, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: course_certificates; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.course_certificates (id, user_id, course_id, enrollment_id, certificate_url, issued_at) FROM stdin;
\.


--
-- Data for Name: course_enrollments; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.course_enrollments (id, user_id, course_id, assigned_by, enrolled_at, due_date, completed_at, progress_percentage, last_accessed_at) FROM stdin;
\.


--
-- Data for Name: email_logs; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.email_logs (id, queue_id, to_email, subject, status, provider, provider_message_id, opened_at, clicked_at, bounced_at, bounce_reason, created_at) FROM stdin;
\.


--
-- Data for Name: email_queue; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.email_queue (id, to_email, to_name, from_email, from_name, subject, html_content, text_content, template_id, template_variables, priority, status, attempts, max_attempts, scheduled_for, sent_at, failed_at, error_message, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_templates; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.email_templates (id, name, subject, template_type, html_content, text_content, variables, is_active, created_by, created_at, updated_at) FROM stdin;
7cb37a81-0c46-4a5f-9a33-209321a7cf41	Welcome	Welcome to Hemera System!	welcome	<h1>Welcome, {{user_name}}!</h1>\r\n<p>We are happy to have you in the Hemera system.</p>\r\n<p>Your access has been created successfully.</p>	Welcome, {{user_name}}!\r\n\r\nWe are happy to have you in the Hemera system.\r\n\r\nYour access has been created successfully.	{"user_name": "User name"}	t	\N	2025-08-04 20:37:54.136778+00	2025-08-04 20:37:54.136778+00
1fd934ba-3c66-466b-a05a-814d4e4f69cc	Course Assigned	New course assigned: {{course_name}}	assignment	<h1>New Course Assigned</h1>\r\n<p>Hello {{user_name}},</p>\r\n<p>A new course has been assigned to you:</p>\r\n<h2>{{course_name}}</h2>\r\n<p>{{course_description}}</p>\r\n<p><strong>Due date:</strong> {{due_date}}</p>	New Course Assigned\r\n\r\nHello {{user_name}},\r\n\r\nA new course has been assigned to you:\r\n\r\n{{course_name}}\r\n{{course_description}}\r\n\r\nDue date: {{due_date}}	{"due_date": "Due date", "user_name": "User name", "course_name": "Course name", "course_description": "Course description"}	t	\N	2025-08-04 20:37:54.136778+00	2025-08-04 20:37:54.136778+00
\.


--
-- Data for Name: lesson_progress; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.lesson_progress (id, user_id, lesson_id, enrollment_id, watched_seconds, completed_at, last_position_seconds, is_completed, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.notification_preferences (id, user_id, email_notifications, push_notifications, assignment_notifications, certificate_notifications, reminder_notifications, marketing_notifications, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.notifications (id, user_id, title, message, type, category, data, is_read, read_at, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: opcoes_resposta; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.opcoes_resposta (id, questao_id, option_text, is_correct, order_number, created_at) FROM stdin;
34ff117b-3912-4a36-abf2-8d285a620e2f	710c8d78-d547-4278-a102-c179d5dccf9d	atitudes abaixo 	t	1	2025-08-05 00:11:22.006748+00
579e0091-7389-4a34-b916-8a7ac19c0d7c	710c8d78-d547-4278-a102-c179d5dccf9d	atitudes abaixo 	f	2	2025-08-05 00:11:22.006748+00
61f85c7f-8509-495c-8d7f-2b921e07a811	710c8d78-d547-4278-a102-c179d5dccf9d	atitudes abaixo 	f	3	2025-08-05 00:11:22.006748+00
765f44be-edbe-4e33-aecb-ca5d4044aeb7	710c8d78-d547-4278-a102-c179d5dccf9d	atitudes abaixo 	f	4	2025-08-05 00:11:22.006748+00
b85da8cd-22aa-4da8-aa4c-7e2491ce2c87	6e067ebd-8d55-42a5-9278-0565312cc74d	Opção A	t	1	2025-08-05 00:13:48.691913+00
8f54b671-f3ac-4b09-ba97-06a34cd41a21	6e067ebd-8d55-42a5-9278-0565312cc74d	Opção B	f	2	2025-08-05 00:13:48.691913+00
08da2183-7fd2-44de-ad57-8722f96713b1	126e41a6-c1c3-4f0d-bfed-346dd72be499	Chegar atrasado com frequência, mas avisar por mensagem.	f	1	2025-08-05 00:19:41.427889+00
90bbfff7-16da-41f5-8e73-d55ab41a64b2	126e41a6-c1c3-4f0d-bfed-346dd72be499	Criticar abertamente colegas na frente dos outros.	f	2	2025-08-05 00:19:41.427889+00
1fd78b8c-7bc5-40f3-84f8-a56048e2b8b0	126e41a6-c1c3-4f0d-bfed-346dd72be499	Cumprir os horários e respeitar prazos estabelecidos.	t	3	2025-08-05 00:19:41.427889+00
7bd64258-76d3-4b2e-8114-8fb6f68b1be4	126e41a6-c1c3-4f0d-bfed-346dd72be499	 Ignorar normas da empresa quando não concordar com elas.	f	4	2025-08-05 00:19:41.427889+00
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.profiles (user_id, full_name, job_position, department, phone, avatar_url, created_at, updated_at) FROM stdin;
00000000-0000-0000-0000-000000000001	Super Administrador	Super Administrador do Sistema	TI	+351 123 456 789	\N	2025-08-04 20:47:39.501018+00	2025-08-04 20:47:39.501018+00
00000000-0000-0000-0000-000000000002	Administrador	Administrador Geral	Administração	+351 987 654 321	\N	2025-08-04 20:47:39.501018+00	2025-08-04 20:47:39.501018+00
00000000-0000-0000-0000-000000000003	João Funcionário	Analista de RH	Recursos Humanos	+351 555 123 456	\N	2025-08-04 20:47:39.501018+00	2025-08-04 20:47:39.501018+00
a04ea6c4-cfda-4be8-a430-81051522586f	Belmiro manuel	gerente	RH	939254152	\N	2025-08-04 21:11:43.337727+00	2025-08-04 21:42:25.919226+00
\.


--
-- Data for Name: questoes; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.questoes (id, simulado_id, question_text, question_type, explanation, order_number, created_at, updated_at) FROM stdin;
710c8d78-d547-4278-a102-c179d5dccf9d	cee2a66b-f5d0-4e16-a9e2-bfdb3a8c722f	Qual das atitudes abaixo representa um comportamento profissional adequado no ambiente de trabalho?	multiple_choice	Pontualidade e comprometimento com prazos demonstram responsabilidade, respeito pelo tempo dos outros e organização. Isso é essencial em qualquer ambiente profissional. Chegar atrasado, criticar colegas ou desrespeitar normas são atitudes negativas que comprometem o bom convívio e a produtividade.	1	2025-08-05 00:11:22.006748+00	2025-08-05 00:11:22.006748+00
6e067ebd-8d55-42a5-9278-0565312cc74d	8d381c92-81b8-4260-ad39-b62a16c9c975	Pergunta teste	multiple_choice	Explicação teste	1	2025-08-05 00:13:48.691913+00	2025-08-05 00:13:48.691913+00
126e41a6-c1c3-4f0d-bfed-346dd72be499	9ffa9009-33fc-4794-a5f9-29c25c8c3616	 Qual das atitudes abaixo representa um comportamento profissional adequado no ambiente de trabalho?	multiple_choice	Pontualidade e comprometimento com prazos demonstram responsabilidade, respeito pelo tempo dos outros e organização. Isso é essencial em qualquer ambiente profissional. Chegar atrasado, criticar colegas ou desrespeitar normas são atitudes negativas que comprometem o bom convívio e a produtividade.\n\n	1	2025-08-05 00:19:41.427889+00	2025-08-05 00:19:41.427889+00
\.


--
-- Data for Name: simulado_attempts; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.simulado_attempts (id, user_id, simulado_id, score, total_questions, correct_answers, started_at, completed_at, status) FROM stdin;
\.


--
-- Data for Name: simulados; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.simulados (id, title, description, duration_minutes, total_questions, difficulty, is_active, created_by, created_at, updated_at) FROM stdin;
cee2a66b-f5d0-4e16-a9e2-bfdb3a8c722f	Comportamento no Local de Serviço	Initializing mock database client for browser environmentInitializing mock database client for browser environment	60	1	medio	t	\N	2025-08-05 00:11:22.006748+00	2025-08-05 00:11:22.006748+00
8d381c92-81b8-4260-ad39-b62a16c9c975	Teste Criação Corrigida	Teste de criação com correção	30	1	facil	t	\N	2025-08-05 00:13:48.691913+00	2025-08-05 00:13:48.691913+00
9ffa9009-33fc-4794-a5f9-29c25c8c3616	Simulado: Comportamento	Simulado: ComportamentoSimulado: ComportamentoSimulado: ComportamentoSimulado: ComportamentoSimulado: ComportamentoSimulado: ComportamentoSimulado: Comportamento	18	1	medio	t	\N	2025-08-05 00:19:41.427889+00	2025-08-05 00:19:41.427889+00
\.


--
-- Data for Name: smtp_config; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.smtp_config (id, name, host, port, username, password_encrypted, use_tls, use_ssl, from_email, from_name, is_active, created_at, updated_at) FROM stdin;
6f6a5be1-6ec8-4198-86a5-b086506063d3	Default SMTP	localhost	587	system@hemera.com	encrypted_password_here	t	f	noreply@hemera.com	Hemera System	t	2025-08-04 20:37:54.149301+00	2025-08-04 20:37:54.149301+00
\.


--
-- Data for Name: template_courses; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.template_courses (id, template_id, content_type, content_id, is_mandatory, default_due_days, priority, created_at) FROM stdin;
\.


--
-- Data for Name: user_answers; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.user_answers (id, attempt_id, questao_id, opcao_resposta_id, answer_text, is_correct, created_at) FROM stdin;
\.


--
-- Data for Name: video_courses; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.video_courses (id, title, description, category, thumbnail_url, duration_minutes, is_active, created_by, created_at, updated_at) FROM stdin;
3497a14e-1022-4b5e-8775-01da30a7b408	Introdução à Empresa	Curso introdutório sobre a cultura e valores da empresa	Cultura	/placeholder.svg	120	t	\N	2025-08-05 19:56:37.331633+00	2025-08-05 19:56:37.331633+00
247f668f-7eb9-4a75-b1c0-b53c33cb59e1	Compliance e Ética	Diretrizes de compliance e código de ética empresarial	Compliance	/placeholder.svg	90	t	\N	2025-08-05 19:56:37.545285+00	2025-08-05 19:56:37.545285+00
dd443a02-39c0-4867-bee5-e7e774faeed6	Processos Internos	Visão geral dos principais processos da empresa	Processos	/placeholder.svg	150	t	\N	2025-08-05 19:56:37.580613+00	2025-08-05 19:56:37.580613+00
ef00637f-48a5-4b13-8c9d-6d595fc7cddf	Desenvolvimento Técnico	Curso técnico para desenvolvedores e equipe de TI	Técnico	/placeholder.svg	240	f	\N	2025-08-05 19:56:37.632054+00	2025-08-05 19:56:37.632054+00
\.


--
-- Data for Name: video_lessons; Type: TABLE DATA; Schema: public; Owner: hemera_user
--

COPY public.video_lessons (id, course_id, title, description, video_url, video_type, duration_minutes, order_number, is_required, min_watch_time_seconds, created_at, updated_at) FROM stdin;
c321dc79-b553-4677-b81f-793d22926027	3497a14e-1022-4b5e-8775-01da30a7b408	Boas-vindas do CEO	Mensagem de boas-vindas do CEO da empresa	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	15	1	t	600	2025-08-05 19:56:37.422014+00	2025-08-05 19:56:37.422014+00
94760505-81cc-4e43-8b45-71f74ce1baae	3497a14e-1022-4b5e-8775-01da30a7b408	História da Empresa	Conheça a história e evolução da nossa empresa	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	20	2	t	900	2025-08-05 19:56:37.524916+00	2025-08-05 19:56:37.524916+00
e1ce4d5c-cd2a-4b76-8d28-85e2bbaaf238	3497a14e-1022-4b5e-8775-01da30a7b408	Valores e Cultura	Nossos valores fundamentais e cultura organizacional	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	25	3	t	1200	2025-08-05 19:56:37.535216+00	2025-08-05 19:56:37.535216+00
074aa6ab-c338-49ee-bfe0-6e8bbcf321d4	247f668f-7eb9-4a75-b1c0-b53c33cb59e1	Código de Ética	Princípios éticos que guiam nossa empresa	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	30	1	t	1500	2025-08-05 19:56:37.555321+00	2025-08-05 19:56:37.555321+00
10c4e3d0-d5e4-4cee-b005-5838ca534668	247f668f-7eb9-4a75-b1c0-b53c33cb59e1	Políticas de Compliance	Políticas e procedimentos de compliance	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	35	2	t	1800	2025-08-05 19:56:37.564414+00	2025-08-05 19:56:37.564414+00
ed3c5d41-3e94-418b-bf63-4976a59e434e	247f668f-7eb9-4a75-b1c0-b53c33cb59e1	Prevenção à Corrupção	Como identificar e prevenir práticas corruptas	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	25	3	t	1200	2025-08-05 19:56:37.571952+00	2025-08-05 19:56:37.571952+00
584fe395-2fb6-488e-84cc-e1522d212b00	dd443a02-39c0-4867-bee5-e7e774faeed6	Fluxo de Trabalho	Como funcionam nossos processos de trabalho	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	40	1	t	2000	2025-08-05 19:56:37.602326+00	2025-08-05 19:56:37.602326+00
291fbdfe-581c-4c12-860c-d6a4027d7bb3	dd443a02-39c0-4867-bee5-e7e774faeed6	Sistemas Internos	Apresentação dos sistemas utilizados na empresa	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	45	2	t	2200	2025-08-05 19:56:37.612848+00	2025-08-05 19:56:37.612848+00
a3177a84-6175-475e-a3c1-952eeea5a853	dd443a02-39c0-4867-bee5-e7e774faeed6	Procedimentos de Qualidade	Padrões de qualidade e procedimentos	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	35	3	f	1500	2025-08-05 19:56:37.623309+00	2025-08-05 19:56:37.623309+00
2eaf8ff5-ea8d-49f7-81fb-aa32421e351b	ef00637f-48a5-4b13-8c9d-6d595fc7cddf	Fundamentos de Programação	Conceitos básicos de programação	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	60	1	t	3000	2025-08-05 19:56:37.642517+00	2025-08-05 19:56:37.642517+00
ccc1f526-7b12-4623-b84f-6e2c90964246	ef00637f-48a5-4b13-8c9d-6d595fc7cddf	Arquitetura de Software	Princípios de arquitetura de software	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	90	2	t	4500	2025-08-05 19:56:37.651333+00	2025-08-05 19:56:37.651333+00
36f5d45c-a0ad-44b5-b4a6-a0f0305e8be7	ef00637f-48a5-4b13-8c9d-6d595fc7cddf	Boas Práticas de Desenvolvimento	Metodologias e boas práticas	https://www.youtube.com/watch?v=dQw4w9WgXcQ	youtube	90	3	t	4500	2025-08-05 19:56:37.673161+00	2025-08-05 19:56:37.673161+00
\.


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: auth; Owner: hemera_user
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: hemera_user
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: assignment_notifications assignment_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.assignment_notifications
    ADD CONSTRAINT assignment_notifications_pkey PRIMARY KEY (id);


--
-- Name: assignment_templates assignment_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.assignment_templates
    ADD CONSTRAINT assignment_templates_pkey PRIMARY KEY (id);


--
-- Name: course_assignments course_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_assignments
    ADD CONSTRAINT course_assignments_pkey PRIMARY KEY (id);


--
-- Name: course_assignments course_assignments_user_id_content_type_content_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_assignments
    ADD CONSTRAINT course_assignments_user_id_content_type_content_id_key UNIQUE (user_id, content_type, content_id);


--
-- Name: course_certificates course_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_certificates
    ADD CONSTRAINT course_certificates_pkey PRIMARY KEY (id);


--
-- Name: course_certificates course_certificates_user_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_certificates
    ADD CONSTRAINT course_certificates_user_id_course_id_key UNIQUE (user_id, course_id);


--
-- Name: course_enrollments course_enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_pkey PRIMARY KEY (id);


--
-- Name: course_enrollments course_enrollments_user_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_user_id_course_id_key UNIQUE (user_id, course_id);


--
-- Name: email_logs email_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_pkey PRIMARY KEY (id);


--
-- Name: email_queue email_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_queue
    ADD CONSTRAINT email_queue_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: lesson_progress lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: lesson_progress lesson_progress_user_id_lesson_id_enrollment_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_user_id_lesson_id_enrollment_id_key UNIQUE (user_id, lesson_id, enrollment_id);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- Name: notification_preferences notification_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_key UNIQUE (user_id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: opcoes_resposta opcoes_resposta_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.opcoes_resposta
    ADD CONSTRAINT opcoes_resposta_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (user_id);


--
-- Name: questoes questoes_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.questoes
    ADD CONSTRAINT questoes_pkey PRIMARY KEY (id);


--
-- Name: simulado_attempts simulado_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.simulado_attempts
    ADD CONSTRAINT simulado_attempts_pkey PRIMARY KEY (id);


--
-- Name: simulados simulados_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.simulados
    ADD CONSTRAINT simulados_pkey PRIMARY KEY (id);


--
-- Name: smtp_config smtp_config_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.smtp_config
    ADD CONSTRAINT smtp_config_pkey PRIMARY KEY (id);


--
-- Name: template_courses template_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.template_courses
    ADD CONSTRAINT template_courses_pkey PRIMARY KEY (id);


--
-- Name: template_courses template_courses_template_id_content_type_content_id_key; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.template_courses
    ADD CONSTRAINT template_courses_template_id_content_type_content_id_key UNIQUE (template_id, content_type, content_id);


--
-- Name: user_answers user_answers_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_pkey PRIMARY KEY (id);


--
-- Name: video_courses video_courses_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.video_courses
    ADD CONSTRAINT video_courses_pkey PRIMARY KEY (id);


--
-- Name: video_lessons video_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.video_lessons
    ADD CONSTRAINT video_lessons_pkey PRIMARY KEY (id);


--
-- Name: idx_users_email; Type: INDEX; Schema: auth; Owner: hemera_user
--

CREATE INDEX idx_users_email ON auth.users USING btree (email);


--
-- Name: idx_assignment_notifications_assignment_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_assignment_notifications_assignment_id ON public.assignment_notifications USING btree (assignment_id);


--
-- Name: idx_assignment_templates_department; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_assignment_templates_department ON public.assignment_templates USING btree (department);


--
-- Name: idx_assignment_templates_job_title; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_assignment_templates_job_title ON public.assignment_templates USING btree (job_title);


--
-- Name: idx_course_assignments_assigned_by; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_assignments_assigned_by ON public.course_assignments USING btree (assigned_by);


--
-- Name: idx_course_assignments_content; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_assignments_content ON public.course_assignments USING btree (content_type, content_id);


--
-- Name: idx_course_assignments_due_date; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_assignments_due_date ON public.course_assignments USING btree (due_date);


--
-- Name: idx_course_assignments_status; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_assignments_status ON public.course_assignments USING btree (status);


--
-- Name: idx_course_assignments_user_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_assignments_user_id ON public.course_assignments USING btree (user_id);


--
-- Name: idx_course_enrollments_course_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_enrollments_course_id ON public.course_enrollments USING btree (course_id);


--
-- Name: idx_course_enrollments_user_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_course_enrollments_user_id ON public.course_enrollments USING btree (user_id);


--
-- Name: idx_email_logs_email; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_email_logs_email ON public.email_logs USING btree (to_email);


--
-- Name: idx_email_logs_status; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_email_logs_status ON public.email_logs USING btree (status);


--
-- Name: idx_email_queue_priority; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_email_queue_priority ON public.email_queue USING btree (priority, scheduled_for);


--
-- Name: idx_email_queue_scheduled; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_email_queue_scheduled ON public.email_queue USING btree (scheduled_for);


--
-- Name: idx_email_queue_status; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_email_queue_status ON public.email_queue USING btree (status);


--
-- Name: idx_lesson_progress_enrollment; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_lesson_progress_enrollment ON public.lesson_progress USING btree (enrollment_id);


--
-- Name: idx_lesson_progress_user_lesson; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_lesson_progress_user_lesson ON public.lesson_progress USING btree (user_id, lesson_id);


--
-- Name: idx_notifications_type; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_notifications_type ON public.notifications USING btree (type);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id, is_read) WHERE (is_read = false);


--
-- Name: idx_notifications_user_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_notifications_user_id ON public.notifications USING btree (user_id);


--
-- Name: idx_profiles_user_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_profiles_user_id ON public.profiles USING btree (user_id);


--
-- Name: idx_template_courses_content; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_template_courses_content ON public.template_courses USING btree (content_type, content_id);


--
-- Name: idx_template_courses_template_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_template_courses_template_id ON public.template_courses USING btree (template_id);


--
-- Name: idx_video_lessons_course_id; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_video_lessons_course_id ON public.video_lessons USING btree (course_id);


--
-- Name: idx_video_lessons_order; Type: INDEX; Schema: public; Owner: hemera_user
--

CREATE INDEX idx_video_lessons_order ON public.video_lessons USING btree (course_id, order_number);


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: auth; Owner: hemera_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON auth.users FOR EACH ROW EXECUTE FUNCTION auth.update_updated_at_column();


--
-- Name: course_enrollments update_assignment_status_trigger; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_assignment_status_trigger AFTER UPDATE ON public.course_enrollments FOR EACH ROW EXECUTE FUNCTION public.update_assignment_status();


--
-- Name: assignment_templates update_assignment_templates_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_assignment_templates_updated_at BEFORE UPDATE ON public.assignment_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: course_assignments update_course_assignments_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_course_assignments_updated_at BEFORE UPDATE ON public.course_assignments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: email_queue update_email_queue_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_email_queue_updated_at BEFORE UPDATE ON public.email_queue FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: email_templates update_email_templates_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_email_templates_updated_at BEFORE UPDATE ON public.email_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: lesson_progress update_lesson_progress_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_lesson_progress_updated_at BEFORE UPDATE ON public.lesson_progress FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: notification_preferences update_notification_preferences_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_notification_preferences_updated_at BEFORE UPDATE ON public.notification_preferences FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: questoes update_questoes_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_questoes_updated_at BEFORE UPDATE ON public.questoes FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: simulados update_simulados_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_simulados_updated_at BEFORE UPDATE ON public.simulados FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: smtp_config update_smtp_config_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_smtp_config_updated_at BEFORE UPDATE ON public.smtp_config FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: video_courses update_video_courses_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_video_courses_updated_at BEFORE UPDATE ON public.video_courses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: video_lessons update_video_lessons_updated_at; Type: TRIGGER; Schema: public; Owner: hemera_user
--

CREATE TRIGGER update_video_lessons_updated_at BEFORE UPDATE ON public.video_lessons FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: assignment_notifications assignment_notifications_assignment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.assignment_notifications
    ADD CONSTRAINT assignment_notifications_assignment_id_fkey FOREIGN KEY (assignment_id) REFERENCES public.course_assignments(id) ON DELETE CASCADE;


--
-- Name: assignment_templates assignment_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.assignment_templates
    ADD CONSTRAINT assignment_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(user_id);


--
-- Name: course_assignments course_assignments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_assignments
    ADD CONSTRAINT course_assignments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.profiles(user_id);


--
-- Name: course_assignments course_assignments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_assignments
    ADD CONSTRAINT course_assignments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id) ON DELETE CASCADE;


--
-- Name: course_certificates course_certificates_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_certificates
    ADD CONSTRAINT course_certificates_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.video_courses(id);


--
-- Name: course_certificates course_certificates_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_certificates
    ADD CONSTRAINT course_certificates_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.course_enrollments(id);


--
-- Name: course_certificates course_certificates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_certificates
    ADD CONSTRAINT course_certificates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: course_enrollments course_enrollments_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.profiles(user_id);


--
-- Name: course_enrollments course_enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.video_courses(id) ON DELETE CASCADE;


--
-- Name: course_enrollments course_enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.course_enrollments
    ADD CONSTRAINT course_enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: email_logs email_logs_queue_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_logs
    ADD CONSTRAINT email_logs_queue_id_fkey FOREIGN KEY (queue_id) REFERENCES public.email_queue(id);


--
-- Name: email_queue email_queue_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_queue
    ADD CONSTRAINT email_queue_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.email_templates(id);


--
-- Name: email_templates email_templates_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(user_id);


--
-- Name: lesson_progress lesson_progress_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.course_enrollments(id) ON DELETE CASCADE;


--
-- Name: lesson_progress lesson_progress_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.video_lessons(id) ON DELETE CASCADE;


--
-- Name: lesson_progress lesson_progress_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: opcoes_resposta opcoes_resposta_questao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.opcoes_resposta
    ADD CONSTRAINT opcoes_resposta_questao_id_fkey FOREIGN KEY (questao_id) REFERENCES public.questoes(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: questoes questoes_simulado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.questoes
    ADD CONSTRAINT questoes_simulado_id_fkey FOREIGN KEY (simulado_id) REFERENCES public.simulados(id) ON DELETE CASCADE;


--
-- Name: simulado_attempts simulado_attempts_simulado_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.simulado_attempts
    ADD CONSTRAINT simulado_attempts_simulado_id_fkey FOREIGN KEY (simulado_id) REFERENCES public.simulados(id);


--
-- Name: simulado_attempts simulado_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.simulado_attempts
    ADD CONSTRAINT simulado_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(user_id);


--
-- Name: simulados simulados_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.simulados
    ADD CONSTRAINT simulados_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(user_id);


--
-- Name: template_courses template_courses_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.template_courses
    ADD CONSTRAINT template_courses_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.assignment_templates(id) ON DELETE CASCADE;


--
-- Name: user_answers user_answers_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES public.simulado_attempts(id) ON DELETE CASCADE;


--
-- Name: user_answers user_answers_opcao_resposta_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_opcao_resposta_id_fkey FOREIGN KEY (opcao_resposta_id) REFERENCES public.opcoes_resposta(id);


--
-- Name: user_answers user_answers_questao_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.user_answers
    ADD CONSTRAINT user_answers_questao_id_fkey FOREIGN KEY (questao_id) REFERENCES public.questoes(id);


--
-- Name: video_courses video_courses_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.video_courses
    ADD CONSTRAINT video_courses_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.profiles(user_id);


--
-- Name: video_lessons video_lessons_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hemera_user
--

ALTER TABLE ONLY public.video_lessons
    ADD CONSTRAINT video_lessons_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.video_courses(id) ON DELETE CASCADE;


--
-- Name: course_certificates System can create certificates; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "System can create certificates" ON public.course_certificates FOR INSERT WITH CHECK ((auth.uid() IS NOT NULL));


--
-- Name: assignment_notifications System can create notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "System can create notifications" ON public.assignment_notifications FOR INSERT WITH CHECK ((auth.uid() IS NOT NULL));


--
-- Name: notifications System can create notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "System can create notifications" ON public.notifications FOR INSERT WITH CHECK ((auth.uid() IS NOT NULL));


--
-- Name: email_queue System can manage email queue; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "System can manage email queue" ON public.email_queue WITH CHECK ((auth.uid() IS NOT NULL));


--
-- Name: user_answers Users can manage own answers; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can manage own answers" ON public.user_answers USING ((EXISTS ( SELECT 1
   FROM public.simulado_attempts sa
  WHERE ((sa.id = user_answers.attempt_id) AND (sa.user_id = auth.uid())))));


--
-- Name: simulado_attempts Users can manage own attempts; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can manage own attempts" ON public.simulado_attempts USING ((auth.uid() = user_id));


--
-- Name: lesson_progress Users can manage own lesson progress; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can manage own lesson progress" ON public.lesson_progress USING ((auth.uid() = user_id));


--
-- Name: notification_preferences Users can manage own notification preferences; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can manage own notification preferences" ON public.notification_preferences USING ((auth.uid() = user_id));


--
-- Name: course_enrollments Users can update own enrollment progress; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can update own enrollment progress" ON public.course_enrollments FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: assignment_notifications Users can update own notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can update own notifications" ON public.assignment_notifications FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM public.course_assignments ca
  WHERE ((ca.id = assignment_notifications.assignment_id) AND (ca.user_id = auth.uid())))));


--
-- Name: notifications Users can update own notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can update own notifications" ON public.notifications FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: profiles Users can update own profile; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: simulados Users can view active simulados; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view active simulados" ON public.simulados FOR SELECT USING ((is_active = true));


--
-- Name: video_courses Users can view active video courses assigned to them; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view active video courses assigned to them" ON public.video_courses FOR SELECT USING (((is_active = true) AND (EXISTS ( SELECT 1
   FROM public.course_enrollments
  WHERE ((course_enrollments.course_id = video_courses.id) AND (course_enrollments.user_id = auth.uid()))))));


--
-- Name: video_lessons Users can view lessons of enrolled courses; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view lessons of enrolled courses" ON public.video_lessons FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.course_enrollments ce
     JOIN public.video_courses vc ON ((vc.id = ce.course_id)))
  WHERE ((ce.user_id = auth.uid()) AND (vc.id = video_lessons.course_id) AND (vc.is_active = true)))));


--
-- Name: opcoes_resposta Users can view opcoes of active simulados; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view opcoes of active simulados" ON public.opcoes_resposta FOR SELECT USING ((EXISTS ( SELECT 1
   FROM (public.questoes q
     JOIN public.simulados s ON ((s.id = q.simulado_id)))
  WHERE ((q.id = opcoes_resposta.questao_id) AND (s.is_active = true)))));


--
-- Name: course_assignments Users can view own assignments; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own assignments" ON public.course_assignments FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: course_certificates Users can view own certificates; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own certificates" ON public.course_certificates FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: course_enrollments Users can view own enrollments; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own enrollments" ON public.course_enrollments FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: assignment_notifications Users can view own notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own notifications" ON public.assignment_notifications FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.course_assignments ca
  WHERE ((ca.id = assignment_notifications.assignment_id) AND (ca.user_id = auth.uid())))));


--
-- Name: notifications Users can view own notifications; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own notifications" ON public.notifications FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: profiles Users can view own profile; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view own profile" ON public.profiles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: questoes Users can view questoes of active simulados; Type: POLICY; Schema: public; Owner: hemera_user
--

CREATE POLICY "Users can view questoes of active simulados" ON public.questoes FOR SELECT USING ((EXISTS ( SELECT 1
   FROM public.simulados s
  WHERE ((s.id = questoes.simulado_id) AND (s.is_active = true)))));


--
-- Name: assignment_notifications; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.assignment_notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: assignment_templates; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.assignment_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: course_assignments; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.course_assignments ENABLE ROW LEVEL SECURITY;

--
-- Name: course_certificates; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.course_certificates ENABLE ROW LEVEL SECURITY;

--
-- Name: course_enrollments; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.course_enrollments ENABLE ROW LEVEL SECURITY;

--
-- Name: email_logs; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.email_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: email_queue; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.email_queue ENABLE ROW LEVEL SECURITY;

--
-- Name: email_templates; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: lesson_progress; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.lesson_progress ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_preferences; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: opcoes_resposta; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.opcoes_resposta ENABLE ROW LEVEL SECURITY;

--
-- Name: questoes; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.questoes ENABLE ROW LEVEL SECURITY;

--
-- Name: simulado_attempts; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.simulado_attempts ENABLE ROW LEVEL SECURITY;

--
-- Name: simulados; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.simulados ENABLE ROW LEVEL SECURITY;

--
-- Name: smtp_config; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.smtp_config ENABLE ROW LEVEL SECURITY;

--
-- Name: template_courses; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.template_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: user_answers; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.user_answers ENABLE ROW LEVEL SECURITY;

--
-- Name: video_courses; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.video_courses ENABLE ROW LEVEL SECURITY;

--
-- Name: video_lessons; Type: ROW SECURITY; Schema: public; Owner: hemera_user
--

ALTER TABLE public.video_lessons ENABLE ROW LEVEL SECURITY;

--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: hemera_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE hemera_user IN SCHEMA auth GRANT ALL ON SEQUENCES  TO hemera_user;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: hemera_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE hemera_user IN SCHEMA auth GRANT ALL ON FUNCTIONS  TO hemera_user;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: hemera_user
--

ALTER DEFAULT PRIVILEGES FOR ROLE hemera_user IN SCHEMA auth GRANT ALL ON TABLES  TO hemera_user;


--
-- PostgreSQL database dump complete
--

